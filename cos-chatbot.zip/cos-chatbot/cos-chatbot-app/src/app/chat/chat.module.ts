import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ChatService } from './chat.service';
import { ChatDialogComponent } from './chat-dialog/chat-dialog.component';

import { NgxAutoScrollModule } from 'ngx-auto-scroll';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgxAutoScrollModule
  ],
  declarations: [ChatDialogComponent],
  exports: [ChatDialogComponent],
  providers: [ChatService]
})
export class ChatModule { }
