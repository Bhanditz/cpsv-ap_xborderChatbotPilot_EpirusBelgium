import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ChatService, Message } from '../chat.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/scan';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'chat-dialog',
  templateUrl: './chat-dialog.component.html',
  styleUrls: ['./chat-dialog.component.css']
})
export class ChatDialogComponent implements OnInit {

  @ViewChild('inputMessage') _inputMessageElement: ElementRef;
  statements: Array<string> = new Array<string>(
    'I would like to start a business.',
    'I would like to stop my business.',
    'I am doing business.',
    'I would like to start a business in belgium.',
  );
  messages: Array<Message> = new Array<Message>();
  formValue: string;

  constructor(public chat: ChatService, private elementRef: ElementRef) {
  }

  ngOnInit() {}

  ngAfterContentInit() {
    const node = this.elementRef.nativeElement.querySelector('#messages');
    const observer = new MutationObserver((mutations) => this.bindLinks());

    observer.observe(node, {
      attributes: true,
      childList: true,
      characterData: true
    });
  }

  // add link to each a element
  bindLinks() {
    const all = this.elementRef.nativeElement.querySelectorAll('.from .content a');

    if (all) {
      all.forEach(elem => {
        if (!elem.onclick) {
          elem.onclick = () => this.triggerService(elem);
        }
      });
    }
  }

  async sendMessage() {
    const msg = this.formValue;
    this.formValue = '';
    if (msg) {
      this.updateChat([new Message(msg, 'user')]);
      this.updateChat(await this.chat.converse(msg).toPromise());
    }
  }

  updateChat(msg: Message[]) {
    // add support for multiple messages of backend
    for (const m of msg) {
      this.messages.push(m);
    }
  }

  async triggerStatement(index: number) {
    this._inputMessageElement.nativeElement.focus();
    this.formValue = this.statements[index];
    await this.sendMessage();
  }

  async triggerService(elem) {
    const selectedService = elem.textContent.split(') ')[1];
    this.formValue = selectedService;
    await this.sendMessage();
  }

  clearChat() {
    // this.messages = this.chat.conversation.asObservable().scan((acc, val) => acc.concat(val));
  }

}
