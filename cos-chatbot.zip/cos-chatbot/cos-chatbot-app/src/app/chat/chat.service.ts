import { Injectable } from '@angular/core';
import { ApiAiClient } from 'api-ai-javascript';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { v4 as uuid } from 'uuid';
import 'rxjs/add/operator/map';

import { environment } from '../../environments/environment';

export class Message {
  constructor(public content: string, public sentBy: string) { }
}

@Injectable()
export class ChatService {

  url = environment.api;
  conversation = new BehaviorSubject<Message[]>([]);

  uuid;

  constructor(private http: HttpClient) {
    this.uuid = uuid();
  }

  // Sends and receives messages via DialogFlow
  converse(msg: string): Observable<Message[]> {
    const chatMessage: any = {
      'message': msg,
      'sessionId': this.uuid,
      'events': []
    };

    return this.http.put(this.url, chatMessage).map((response: any) => {
        // add support for multiple messages from backend
        console.log(chatMessage.sessionId);
        const messageArray = response.result.fulfillment.messages;

        if (!messageArray) {
          return [new Message('Didn\'t understood that. Please try again or paste the exact name.', 'bot')];
        }

        const messages = [];
        for (const message of messageArray) {
          if (message.type !== 'simple_response' && message.platform !== 'google') {
            messages.push(new Message(message.speech, 'bot'));
          }
        }
        return messages; // new Message(speech, 'bot');
      });
  }

  // Adds message to source
  update(msg: Message) {
    this.conversation.next([msg]);
  }

}
