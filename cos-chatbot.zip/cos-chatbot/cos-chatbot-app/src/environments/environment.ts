export const environment = {
  production: false,
  api: 'http://localhost:3000/api/chats',
  dialogflow: {
    angularBot: 'b2e77d1e10574c9fa8290aa33c2a7469'
  }
};
