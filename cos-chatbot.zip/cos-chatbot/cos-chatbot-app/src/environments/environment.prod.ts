export const environment = {
  production: true,
  api: 'http://cos-chatbot-api.pwc.delivery/api/chats',
  dialogflow: {
    angularBot: 'b2e77d1e10574c9fa8290aa33c2a7469'
  }
};
