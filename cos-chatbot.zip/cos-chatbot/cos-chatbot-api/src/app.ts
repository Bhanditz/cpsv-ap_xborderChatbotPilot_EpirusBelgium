import * as express from 'express';
import * as bodyParser from 'body-parser';
import * as cors from 'cors';
import * as morgan from 'morgan';
import * as errorHandler from 'errorhandler';
import * as methodOverride from 'method-override';
import * as apiai from 'apiai-promise';

import { MainConfig } from './config/main.config';
import { MainPageRouter } from './routes/mainpage.router';
import { DialogflowRouter } from './routes/dialogflow.router';
import { ChatRouter } from './routes/chat.router';

export class App {

  private app: express.Express;

  private indexRouter: MainPageRouter;
  private dialogflowRouter: DialogflowRouter;
  private chatRouter: ChatRouter;
  public static dialogflowClient: apiai.Application =  apiai(MainConfig.dialogflow);

  constructor() {
    this.app = express();
    this.app.use('/assets', express.static(__dirname + '/assets'));
  }

  public runApp() {
    this.initMiddleware();
    this.setRoutes();
    this.startServer();
  }

  public initMiddleware() {
    console.log('init middleware');
    this.app.disable('x-powered-by');
    this.app.use(bodyParser.urlencoded({ extended: true }));
    this.app.use(bodyParser.json());
    this.app.use(methodOverride());
    this.app.use(cors());
    if (MainConfig.development) {
      this.app.use(morgan('dev'));  // http request logging
      this.app.use(errorHandler());  // show info about error
    }
  }

  public setRoutes() {
    console.log('init routes')
    let apiRoutes = express.Router();
    let webRoutes = express.Router();

    this.indexRouter = new MainPageRouter();
    this.dialogflowRouter = new DialogflowRouter();
    this.chatRouter = new ChatRouter();

    // define web routes
    webRoutes.use('/', this.indexRouter.router);
    this.app.use('/', webRoutes);

    // define api routes
    apiRoutes.use('/chats', this.chatRouter.router);
    apiRoutes.use('/dialogflow', this.dialogflowRouter.router);
    this.app.use('/api', apiRoutes);
  }

  public startServer() {
    let server = this.app.listen(MainConfig.port, function () {
      console.log('Server listening on port ' + server.address().port);
    });
  }

}

var app = new App();
app.runApp();
