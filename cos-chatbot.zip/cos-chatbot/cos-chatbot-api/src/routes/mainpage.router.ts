import { Router } from 'express';
import { MainPageController } from '../controllers/mainpage.controller'

export class MainPageRouter {

  router: Router

  constructor() {
    this.router = Router();
    this.router.get('/', new MainPageController().index);
  }

}