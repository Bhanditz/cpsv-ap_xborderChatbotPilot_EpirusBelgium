import { Router } from 'express';
import { ChatController } from '../controllers/chat.controller';

export class ChatRouter {

  router: Router

  constructor() {
    this.router = Router();
    const d: ChatController = new ChatController();

    this.router.post('/', d.create);
    this.router.get('/:id?', d.read);
    this.router.put('/:id?', d.update);
    this.router.delete('/:id', d.delete);
  }

}
