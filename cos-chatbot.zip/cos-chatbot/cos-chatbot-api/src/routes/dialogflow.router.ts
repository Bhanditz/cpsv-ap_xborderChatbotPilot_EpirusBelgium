﻿import { Router } from 'express';
import { DialogflowController } from '../controllers/dialogflow.controller';

export class DialogflowRouter {

  router: Router

  constructor() {
    this.router = Router();

    const d: DialogflowController = new DialogflowController();
    this.router.post('/', d.process.bind(d));
  }

}
