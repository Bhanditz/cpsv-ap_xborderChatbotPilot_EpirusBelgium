import { createPool, Connection, FieldInfo, Pool, EscapeFunctions } from 'mysql'
import { MainConfig } from '../config/main.config';

/**
 * This class is responsible for maintaining the database connection and sending SQL queries.
 */
export class DatabaseService {

    private static pool: Pool;

    private static getPool(): Pool {

        if(!DatabaseService.pool) {
            DatabaseService.pool = createPool({
                connectionLimit : 10,
                host     : MainConfig.db_host,
                user     : MainConfig.db_user,
                password : MainConfig.db_password,
                database : 'cos_chatbot'
              });
        }

        return DatabaseService.pool;
    }

    /**
     * Send an SQL query to the database.
     * @param queryTemplate An SQL query. Variables are indicated with a question mark (?).
     * @param values An ordered list of values that should be filled in the queryTemplate.
     */
    public static sendSQLRequest(queryTemplate: string, values: (number|string)[]): Promise<{results: any, fields: FieldInfo[]}> {

        return new Promise(function(fulfilled, rejected) {

            DatabaseService.getPool().query(queryTemplate, values, function (error, results, fields) {
                if (error){
                    console.error('An error happened while trying to send the request.');
                    return rejected(error);
                }

                fulfilled({results, fields});

            });

        });

    }

}
