﻿export class MainConfig {

  public static readonly development: boolean = process.env.NODE_ENV != 'production';
  public static readonly port: string = process.env.port || '3000';

  // DB config values
  public static readonly db_host: string = process.env.MYSQL_DB_HOST || 'localhost';
  public static readonly db_user: string = 'root';
  public static readonly db_password: string = process.env.MYSQL_DB_PASSWORD || 'test_password';

  // API config & Keys section
  public static dialogflow: string = (process.env.NODE_ENV != 'production') ? 'c3c04525b6a64d01b6af4f1ded5b2b4c' : 'd1e3725f538c4da18cdc7a8b20c06d98';

}
