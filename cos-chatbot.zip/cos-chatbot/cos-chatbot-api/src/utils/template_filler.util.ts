/**
 * This class is responsible for formatting template strings.
 * A template string is a normal string with variables that should be swapped for real values.
 * Use ${var_name} to indicate variables.
 * For example: "The answer to your question is ${answer}."
 */
export class TemplateFiller {

    /**
     * Fill in a template string.
     * @param template A template string with values that can be interpolated.
     * @param params The parameters, e.g.: {value: "interpolated"}. Nested parameters will not work.
     */
    public static fill_in(template: string, params: any): string {
        let tpl = template.replace(/\${(?!this\.)/g, "${this.");
        let tpl_func = new Function(`return \`${tpl}\``);

        return tpl_func.call(params);
    }

    /**
     * Take a random string from the possibilities and fill in the parameter values.
     * @param possibilities An array of template strings, from which 1 will be taken at random. 
     * @param params The parameters, e.g.: {value: "interpolated"}. Nested parameters will not work.
     */
    public static get_random_filled(possibilities: string[], params: any): string {
        let rand = possibilities[Math.floor(Math.random() * possibilities.length)];
        return TemplateFiller.fill_in(rand, params);
      }

}