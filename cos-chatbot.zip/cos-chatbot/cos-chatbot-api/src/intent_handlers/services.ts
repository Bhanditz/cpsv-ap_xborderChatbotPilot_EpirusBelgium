import { DatabaseService } from '../database/database.service';
import _ from 'lodash';

const mapBusinessType = {
  'want to start': 'starting',
  'own': 'doing',
  'want to close': 'closing'
};

export class ServicesHandler {

    public static async handleBusinessType(agent) {
      const country: string = agent.parameters['cos-country'].trim().toLowerCase();
      const businessType: string = mapBusinessType[agent.parameters['business-type'].trim()];

      const serviceName: string|null = await ServicesHandler.find(businessType, country);

      if (!serviceName) {
        return agent.add(`I\'m sorry, but we couldnt find any services in ${country}.`);
      }

      agent.add(serviceName);
    }

    public static async handleServiceType(agent) {
      const country: string = (agent.parameters['cos-country'] || agent.contexts[agent.contexts.length - 1].parameters['cos-country']).trim().toLowerCase();
      const serviceName: string = agent.parameters['service-name'].trim();
      const businessType: string = mapBusinessType[agent.contexts[agent.contexts.length - 1].parameters['business-type']];

      const explanation: string|null = await ServicesHandler.findInfo(serviceName, country, businessType);

      if (!explanation) {
        return agent.add(`I\'m sorry, but we couldnt find any service info from ${serviceName}.`);
      }

      agent.add(explanation);
    }

    public static async handleServiceInfo(agent) {
      const infoType: string = agent.parameters['contact'].trim();
      const serviceName: string = agent.parameters['service-name'] || agent.contexts[0].parameters['service-name'];

      const info: string|null = await ServicesHandler.findAdditionalInfo(serviceName, infoType);

      if (!info) {
        return agent.add(`I\'m sorry, but we couldnt find any additional info.`);
      }

      agent.add(info);
    }

    private static handleInfoResponse(result, infoType: string) {
      if (infoType === 'address' && (result.street && result.city)) {
        return `Thats ${result.street} ${result.box}, ${result.city} ${result.postal_code}`;
      }
      else if (infoType === 'email' && result.email) {
        return `You can contact them on ${result.email}`;
      }
      else if (infoType === 'phone' && result.phone) {
        return `Their phone number is: ${result.phone}`;
      }
      else if (infoType === 'website' && result.website) {
        return `You can find more information on: ${result.website}`;
      }

      return `Sorry, we didn\'t found any ${infoType} info`;
    }

    private static async find(businessType: string, country: string): Promise<string|null> {
      const query = [
        'SELECT *',
        'FROM `services`',
        'WHERE country = ?',
        'AND business_type = ?'
      ].join(' ');

      const results = (await DatabaseService.sendSQLRequest(query, [country, businessType])).results;

      if(results.length == 0) {
        console.log(`Service name for ${businessType} and ${country} not found.`);
        return null;
      }

      const services = results.map(res => `<br /><a href="javascript:void(0)">${res.list_id}) ${res.name}</a>`).join(' ');
      return `Which of the following services would you like to use? ${services}`;
    }

    private static async findInfo(serviceName: string, country: string, businessType: string): Promise<string|null> {
      const query = [
        'SELECT name, description',
        'FROM `services`',
        'WHERE country = ?',
        'AND name = ?',
        'AND business_type = ?',
      ].join(' ');
      const results = (await DatabaseService.sendSQLRequest(query, [country, serviceName, businessType])).results;

      if(results.length == 0) {
        console.log(`Explanation findInfo for ${serviceName} not found.`);
        return null;
      }

      return results[0].description;
    }

    private static async findAdditionalInfo(serviceName: string, additionalInfoType: string): Promise<string|null> {
      const query = [
        'SELECT * FROM `services`',
        'WHERE name = ?'
      ].join(' ');

      const results = (await DatabaseService.sendSQLRequest(query, [serviceName])).results;

      if(results.length == 0) {
        console.log(`Explanation findAdditionalInfo for ${serviceName} not found.`);
        return null;
      }

      return ServicesHandler.handleInfoResponse(results[0], additionalInfoType);
    }

}
