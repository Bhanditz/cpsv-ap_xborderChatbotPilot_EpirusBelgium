const excelToJson = require('convert-excel-to-json');
const _ = require('lodash');
const dialogflow = require('dialogflow');
const { createPool, Connection, FieldInfo, Pool, EscapeFunctions } = require('mysql');
const credentials = require('./cos-chatbot-958ca-00ba794449ca.json');

const pool = createPool({
  connectionLimit: 10,
  host: 'localhost',
  user: 'root',
  password: 'test_password',
  database: 'cos_chatbot'
});

const countries = ['greece', 'belgium'];
const entries = [];
let count = 1;

countries.forEach(country => {
  const sheets = excelToJson({
    sourceFile: `cos_${country}_data.xlsx`,
    header: { rows: 1 },
    columnToKey: { '*': '{{columnHeader}}' }
  });

  sheets['Public Service'].some(row => {
    const pickItemFromArray = (source, property, comparedTo) => source.filter(item => (_.get(item, property) === comparedTo))[0];

    // skip this row if there's no new service
    if (!_.get(row, 'Name')) {
      return;
    }

    const id = row['PSIdentifier'];
    const name = row['Name'];
    const description = row['Description'];
    const groupedBy = row['Is Grouped By']; // http://data.europa.eu/BE/StartingBusiness
    const hasContactPoint = row['Has Contact Point']; // http://data.europa.eu/ContactPoint/Fedict/diamonds
    const findHasAddress = row['Has Competent Authority']; // AFER/FED/SPF/FOD/Taxation

    const linkAddressSheet = pickItemFromArray(sheets['Public Organisation'], 'PublicOrganisationIdentifier', findHasAddress);

    const businessEvent = pickItemFromArray(sheets['Business Event'], 'BEIdentifier', groupedBy);
    const contactPoint = pickItemFromArray(sheets['Contact Point'], 'ContactIdentifier', hasContactPoint);
    const address = pickItemFromArray(sheets['Address'], 'AddressIdentifier', linkAddressSheet['Has Address']);

    // belgian options: Starting business, Doing business, Closing
    // greece options: Starting business: Needing a license, permit or ce..., Doing business:  Needing a license, permit or cert..., Closing business
    const mapBusinessType = (type) => {
      if (type.toLowerCase().includes('starting')) {
        return 'starting';
      }
      if (type.toLowerCase().includes('doing')) {
        return 'doing';
      }
      if (type.toLowerCase().includes('closing')) {
        return 'closing';
      }
    };

    entries.push({
      id,
      list_id: count,
      name: name.replace(/ *\([^)]*\) */g, '').replace('/', ' ').trim(),
      description,
      business_type: mapBusinessType(_.get(businessEvent, 'Name')), // business event
      email: _.get(contactPoint, 'Has Email'), // email
      phone: _.get(contactPoint, 'Has Telephone'), // telephone
      website: _.get(contactPoint, 'URL'), // url
      street: _.get(address, 'Full Address'), // Italiëlei, 124
      box: _.get(address, 'poBox'), // 71
      alternative_name: _.get(address, 'Locator Name'), // North Galaxy
      city: _.get(address, 'Admin Unit L1'), // Anvers
      postal_code: _.get(address, 'Post Code'), // 2000
      country
    });

    count++;
  });
});

const createTableQuery = [
  'CREATE TABLE IF NOT EXISTS services ( ',
    'id VARCHAR(255) DEFAULT NULL,',
    'list_id INT(11) DEFAULT NULL,',
    'name VARCHAR(255) DEFAULT NULL,',
    'description TEXT DEFAULT NULL,',
    'business_type VARCHAR(255) DEFAULT NULL,',
    'email VARCHAR(255) DEFAULT NULL,',
    'phone VARCHAR(255) DEFAULT NULL,',
    'website VARCHAR(255) DEFAULT NULL,',
    'street VARCHAR(255) DEFAULT NULL,',
    'box VARCHAR(255) DEFAULT NULL,',
    'alternative_name VARCHAR(255) DEFAULT NULL,',
    'city VARCHAR(255) DEFAULT NULL,',
    'postal_code VARCHAR(255) DEFAULT NULL,',
    'country VARCHAR(255) DEFAULT NULL',
  ') engine=InnoDB'
].join(' ');
const query = [
  'REPLACE INTO services (id, list_id, name, description, business_type, email, phone, website, street, box, alternative_name, city, postal_code, country)',
  'VALUES ?'
].join(' ');
const values = entries.map(entry => Object.values(entry));

pool.query(createTableQuery, [], (err, results, fields) => {
  if (err) {
    return console.error('An error happened while creating the table.', err);
  }

  pool.query(query, [values], (err, results, fields) => {
    if (err) {
      return console.error('An error happened while trying to send the request.', err);
    }

    console.log(results);
  });
});

const projectId = 'cos-chatbot-958ca';
const parentId = 'aea459ab-8169-47e8-b2c6-8a0814f4820c';
const childId = '981d950d-b14b-4731-a314-b9c2063600a5';

const createIntent = () => {
  // Instantiates clients
  const contextsClient = new dialogflow.ContextsClient({ credentials });
  const intentsClient = new dialogflow.IntentsClient({ credentials });
  const agentPath = intentsClient.projectAgentPath(projectId);

  const result = {
    action: 'cos-business.cos-business-custom',
    parameters: [{
      displayName: 'service-name',
      value: '$service-name',
      entityTypeDisplayName: '@service-name',
      mandatory: true,
      prompts: ['Didn\'t understood that. Please try again or paste the exact name.']
    }],
    parentFollowupIntentName: `projects/${projectId}/agent/intents/${parentId}`,
    followupIntentInfo: [{
      followupIntentName: `projects/${projectId}/agent/intents/${childId}`,
      parentFollowupIntentName: `projects/${projectId}/agent/intents/${childId}`
    }],
    messages: [],
    inputContextNames: [
      contextsClient.contextPath(projectId, '*', 'cos-business-followup')
    ],
    outputContexts: [{
      name: contextsClient.contextPath(projectId, '*', 'cos-service-type-followup'),
      lifespanCount: 999,
    }]
  };

  const sizeRequest = {
    parent: agentPath,
    intent: {
      // displayName: 'cos-service-type',
      displayName: 'cos-service-type',
      events: [],
      // Webhook is disabled because we are not ready to call the webhook yet.
      webhookState: 'WEBHOOK_STATE_ENABLED',
      trainingPhrases: entries.map(entry => ({ type: 'EXAMPLE', parts: [{ text: entry.name, entityType: '@service-name', alias: 'service-name'}] })),
      mlEnabled: true,
      priority: 500000,
      ...result
    }
  };

  intentsClient
    .createIntent(sizeRequest)
    .then(responses => {
      console.log('Created size entity type:');
      console.log(responses[0]);
    })
    .catch(err => {
      console.error('ERROR:', err);
    });
};

const createEntity = () => {
  // Instantiates clients
  const entityTypesClient = new dialogflow.EntityTypesClient({ credentials });
  const intentsClient = new dialogflow.IntentsClient({ credentials });

  // The path to the agent the created entity type belongs to.
  const agentPath = intentsClient.projectAgentPath(projectId);

  // Create an entity type named "size", with possible values of small, medium
  // and large and some synonyms.
  const sizeRequest = {
    parent: agentPath,
    entityType: {
      displayName: 'service-name',
      kind: 'KIND_MAP',
      autoExpansionMode: 'AUTO_EXPANSION_MODE_UNSPECIFIED',
      entities: entries.map(entry => ({ value: entry.name, synonyms:[entry.list_id, entry.name] }))
    },
  };

  entityTypesClient
    .createEntityType(sizeRequest)
    .then(responses => {
      console.log('Created size entity type:');
      console.log(responses[0]);
      createIntent();
    })
    .catch(err => {
      console.error('Failed to create size entity type:', err);
    });
};

// first create entity followed by creating intent where we assign the entity
createEntity();
