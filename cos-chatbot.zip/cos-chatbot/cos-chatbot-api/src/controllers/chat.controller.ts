import { Request, Response, NextFunction } from 'express';
import { App } from '../app';

export class ChatController {

  constructor() { }

  /**
   * --- This api call is currently disabled due to specification. ---
   * Create a new chat ressource.
   */
  public create(req: Request, res: Response, next: NextFunction) {
    return res.sendStatus(403);
  }

  /**
   * --- This api call is currently disabled due to specification. ---
   * Read all or one chat ressource depending whether it is referenced by id.
   */
  public read(req: Request, res: Response, next: NextFunction) {
    res.sendStatus(404);
  }

  /**
   * Update a chat ressource if referenced by id. Handles incoming chat messages.
   */
  public async update(req: Request, res: Response, next: NextFunction) {
    console.log('[PUT] /api/chats called ..');

    const sessionId: string = (req.body && req.body['sessionId']) ? req.body['sessionId'] : undefined;
    const message: string = (req.body && req.body['message']) ? req.body['message'] : undefined;
    const events: Array<string> = (req.body && req.body['events']) ? req.body['events'] : undefined;
    console.log(sessionId);
    if (sessionId && message && events) {
      let response = await App.dialogflowClient.textRequest(message, { sessionId: sessionId });
      res.statusCode = 200;
      return res.send(response);
    } else {
      return res.sendStatus(400);
    }
  }

  /**
   * --- This api call is currently disabled due to specification. ---
   * Delete a chat ressource if referenced by id.
   */
  public delete(req: Request, res: Response, next: NextFunction) {
    return res.sendStatus(404);
  }

}
