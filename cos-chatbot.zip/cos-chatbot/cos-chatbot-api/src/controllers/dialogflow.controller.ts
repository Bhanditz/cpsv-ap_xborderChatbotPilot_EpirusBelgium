import { Request, Response } from 'express';
import { WebhookClient } from 'dialogflow-fulfillment';
import { ServicesHandler } from '../intent_handlers/services';

/**
 * This controller is responsible from the webhook requests from Dialogflow.
 */
export class DialogflowController {

  private readonly intentMap: Map<String, Function> = new Map(); // Maps functions to Dialogflow intent names

  constructor() {
    this.intentMap.set('cos-business', ServicesHandler.handleBusinessType);
    this.intentMap.set('cos-business - more', ServicesHandler.handleBusinessType);
    this.intentMap.set('cos-service-type', ServicesHandler.handleServiceType);
    this.intentMap.set('cos-service-info', ServicesHandler.handleServiceInfo);
  } 

  public async process(req: Request, res: Response) {
    console.log('Dialogflow process method called...');
    console.log(JSON.stringify(req.body));

    const agent = new WebhookClient({request: req, response: res});

    try {
      await agent.handleRequest(this.intentMap);
    } catch(err) {
      console.error(err);
      return res.status(500).send(JSON.stringify(err));
    }
  }

}
