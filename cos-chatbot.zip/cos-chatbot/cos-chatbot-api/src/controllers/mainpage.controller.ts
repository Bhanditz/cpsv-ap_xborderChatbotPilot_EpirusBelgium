﻿import { Request, Response } from 'express';

export class MainPageController {

  private static readonly appTitle = 'PwC ISA CoS ChatBot API';
  private static readonly appVendor = 'PwC IT Services GmbH';
  private static readonly appYear = '2018';

  private static readonly indexHtml: string = `
  <html>
  <head>
  <title>`+ MainPageController.appTitle +`</title>
  <link rel="icon" type="image/png" href="./assets/favicon.ico" />
  <style>
    body {
      background:white;
      font-family:Georgia;
      text-align:center;
      display:flex;
      align-items:center;
    }

    content {
      margin: 0 auto;
    }

    h2, h3 {
      animation:annoy 0.5s;
      -moz-animation:annoy 0.5s infinite;
      -webkit-animation:annoy 0.5s infinite;
    }

    img {
      width: 300px;
      height: 300px;
    }

    @-moz-keyframes annoy {
      0%   {color:404041;}
      100%   {color:#e0301e;}
    }

    @-webkit-keyframes annoy {
      0%   {color:404041;}
      100%   {color:#e0301e;}
    }
  </style>
  </head>
  <body>
    <content>
      <img src="./assets/logo.svg"/>
      <h2>`+ MainPageController.appTitle +`</h2>
      <h3>© ` + MainPageController.appYear + ` ` + MainPageController.appVendor + `</h3>
    </content>
  </body>
  </html>
`;

  constructor() {}

  index(req: Request, res: Response) {
    res.send(MainPageController.indexHtml);
  }

}
