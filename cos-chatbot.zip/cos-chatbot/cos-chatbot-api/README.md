

# CoS Chatbot API

CoS Chatbot API is a  
1) Web Service that extracts file data and adds it to a mysql database and
dialogflow.  
2) API handles the chat api calls and the dialogflow webhook.  

Current data files.

 - **[Greece]** src/scripts/cos_greece_data.xlsx
 - **[Belgium]** src/scripts/cos_belgium_data.xlsx

# Install and run

     git clone https://gitlab.pwc.delivery/cos/cos-chatbot-api

     yarn && nodemon

Development: http://localhost:4124/  
Production: http://cos-chatbot.pwc.delivery/

## Scripts

`src/scripts/xlsx-to-json.js`  
Run with `node xlsx-to-json.js`;

This will execute 3 actions:
- [mysql] Read through the (currently) 2 country files and add them to our mysql db
- [dialogflow] Create an entity with all the service names and their possible keywords, like the numbers 1,2,3,...
- [dialogflow] Create an intent

To bring this to production:
- sql = export sql db and import in production
- dialogflow = export and import in production

## Files

`src/intent_handlers/service.ts`  
In this file we handle all the webhook requests. Requesting services name, description, phone data, website, etc..

`src/controllers/chat.controller.ts`  
Handles all the chat api calls that our frontend sends. Updating, reading, creating chats.

`src/config/main.config.ts`  
config data

## Learnings

We've seen that a lot is possible if we use their API to dynamically add intents/entities and everything that is needed which we substract from the files.
We've noticed that the more data, the more specific we can answer the questions. One way to do this would be to use data that real life users have asked. We could get this data i.e. out of a helpdesk database.

We've noticed that service names with parentheses = (, ) or slashes = /, \ couldn't be recognised. So we have to avoid those signs.

## Scenarios



**Client:** Hey  
**Bot:** Hi! Would you like to start a business, stop a business or do you own a business?  

**Client:** i would like to stop my business  
**Bot:**  In which country?  

**Client:** france  
**Bot:** I’m sorry, but we couldn't find any services in france.  

**Client:** belgium then  
**Bot:** Which of the following services would you like to use? 1) Cessation of VAT activity 2) Cessation of activity of a driving school, etc...  

*Other options are: give in the service number. i.e. 1, 2, 3, etc... Or you can click the activity*   

**Client:** Cessation of activity of a driving school  
**Bot:** The driving school administrator notifies the temporary or permanent cessation of activity by certified mail or a certified electronic method in the term of 8 days.  

**Client:** Is there any contact info?  
**Bot:** Their phone number is: +32(0)22773111  

**Client:** what about an email?  
**Bot:** You can contact them on  info@mobilit.fgov.be  

**Client:** Thanks!  
**Bot:** It was a pleasure. Have a nice day!  
